a = "afnksjd,  /n"

print(a.replace("  ","").replace(",","").replace("/n",""))
