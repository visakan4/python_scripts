import os
import re
import numpy as np
import string
import json
from flask import Flask
from flask_cors import CORS,cross_origin
from flask import request
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import svm
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
from sklearn.neural_network import MLPClassifier

def readFiles(filePath,fileName):
    fileLocation = filePath+"/"+fileName
    return open(fileLocation).read()


def getFileData(dataSetPath,fileList):
    dataSet = []
    for f in fileList:
        dataSet.append(readFiles(dataSetPath,f))
    return dataSet


def getLabels(fileList):
    fileNames = []
    for file in fileList:
        fileNames.append(file.split("_")[0])
    return fileNames


def readDataset(dataSetPath, splitPercent):
    fileList = os.listdir(dataSetPath)
    fileNames = getLabels(fileList)
    dataSet = getFileData(dataSetPath,fileList)
    X_train, X_test, X_train_labels, X_test_lables = train_test_split(dataSet,fileNames,test_size=splitPercent)
    return dataSet,fileNames,X_train, X_test, X_train_labels, X_test_lables


def preprocess(corpus,lower,punc,number):
    for index,data in enumerate(corpus):
        # removing punctuations
        data = re.sub('\s+', '  ', data).strip()
        if (lower):
            data = data.lower()
        if (punc):
            # data = re.sub('[!@#$%^\.=&\*()_\+]', ' ', data)
            for punctuation in string.punctuation:
                data = data.replace(punctuation, "")
        if (number):
            data = re.sub(r'[0-9]','',data)
        corpus[index] = data
    return (corpus)


def getDocumentTermMatrix(corpus,fileNames,style,splitPercent):
    if (style == 'count'):
        countVector = CountVectorizer(ngram_range=(1, 1))
        count_document_matrix = countVector.fit_transform(corpus)
        count_document_matrix_label_names = countVector.get_feature_names()
        train_document_matrix, test_document_matrix, train_label, test_label = train_test_split(count_document_matrix,fileNames,test_size=splitPercent)
        return train_document_matrix, test_document_matrix, train_label, test_label
    elif (style == 'tf_idf'):
        tf_idf = TfidfVectorizer(ngram_range=(1,1))
        tf_idf_matrix = tf_idf.fit_transform(corpus)
        tf_idf_matrix_label_names = tf_idf.get_feature_names()
        return tf_idf_matrix.toarray(), tf_idf_matrix_label_names


def trainModel(document_term_matrix, X_train_labels,classifierName):
    if (classifierName == 'svm'):
        classifier = svm.SVC(kernel='linear')
    elif (classifierName == 'decisiontree'):
        classifier = DecisionTreeClassifier(max_depth=5)
    elif (classifierName == 'randomForestClassifier'):
        classifier = RandomForestClassifier(max_depth=5,n_estimators=1,max_features=1)
    elif (classifierName == 'naive-bayes'):
        classifier = MultinomialNB()
    elif (classifierName == 'mlp'):
        classifier = MLPClassifier(solver='lbfgs', alpha=1e-5,hidden_layer_sizes = (5, 2), random_state = 1)
    return classifier.fit(document_term_matrix, X_train_labels)


def predictValues(classifier,test_document_matrix,classifierName):
    return classifier.predict(test_document_matrix)


def evaluate(true_label,predicted_labels):
    return (accuracy_score(true_label, predicted_labels))


def flow(splitPercent,lower,punc,number,style):
    dataSet, fileNames, X_train, X_test, X_train_labels, X_test_lables = readDataset("D:/Semester1/VisualAnalytics/Assignment/Assignment2/classification",0.25)
    preProcessedDataSet = preprocess(dataSet,lower,punc,number)
    train_document_matrix, test_document_matrix, train_label, test_label = getDocumentTermMatrix(preProcessedDataSet,fileNames,style,splitPercent)
    classifierNames = ["svm","naive-bayes","mlp","randomForestClassifier","decisiontree"]
    valueTobeReturned = []
    for classifierName in classifierNames:
        classifierValue = {}
        classifier = trainModel(train_document_matrix,train_label,classifierName)
        predicted_labels = predictValues(classifier,test_document_matrix,classifierName)
        accuracy_value = evaluate(test_label,predicted_labels)
        classifierValue['classifier_name'] = classifierName
        classifierValue['classifier_accuracy'] = accuracy_value * 100
        valueTobeReturned.append(classifierValue)
    return json.dumps(valueTobeReturned)


app = Flask(__name__)
app.config['CORS_HEADERS'] = 'Content-Type'


@app.route("/getValues",methods=['GET','POST'])
@cross_origin()
def hello():
    jsonData = request.get_json()
    number = jsonData['numbers']
    lower = jsonData['lowerCase']
    punctuations = jsonData['punctuations']
    splitPercent = jsonData['splitPercent']
    style = jsonData['style']
    print(splitPercent)
    print(lower)
    print(punctuations)
    print(number)
    return flow(splitPercent,lower,punctuations,number,style)


if __name__ == '__main__':
    app.run()
